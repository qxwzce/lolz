<?php

namespace Lava\Api\Exceptions;

use Exception;

class BaseException extends Exception
{



}