<?php

namespace Lava\Api\Exceptions\H2h;

use Exception;

class H2hException extends Exception
{

}