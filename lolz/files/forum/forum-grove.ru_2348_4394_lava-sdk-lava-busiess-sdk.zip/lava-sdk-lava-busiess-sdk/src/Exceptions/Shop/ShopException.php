<?php

namespace Lava\Api\Exceptions\Shop;

use Lava\Api\Exceptions\BaseException;

class ShopException extends BaseException
{

}