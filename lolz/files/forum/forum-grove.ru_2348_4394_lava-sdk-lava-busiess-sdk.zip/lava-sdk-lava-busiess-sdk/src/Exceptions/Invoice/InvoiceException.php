<?php

namespace Lava\Api\Exceptions\Invoice;

use Exception;

class InvoiceException extends Exception
{

}