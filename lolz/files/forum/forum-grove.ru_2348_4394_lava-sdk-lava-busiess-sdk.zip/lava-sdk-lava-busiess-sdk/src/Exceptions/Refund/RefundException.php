<?php

namespace Lava\Api\Exceptions\Refund;

use Lava\Api\Exceptions\BaseException;

class RefundException extends BaseException
{

}