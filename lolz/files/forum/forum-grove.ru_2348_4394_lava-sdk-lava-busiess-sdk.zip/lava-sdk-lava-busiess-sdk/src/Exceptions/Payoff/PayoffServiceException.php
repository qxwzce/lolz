<?php

namespace Lava\Api\Exceptions\Payoff;

use Lava\Api\Exceptions\BaseException;

class PayoffServiceException extends BaseException
{

}