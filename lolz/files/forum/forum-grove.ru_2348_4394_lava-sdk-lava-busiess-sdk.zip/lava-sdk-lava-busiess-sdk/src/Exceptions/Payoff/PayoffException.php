<?php

namespace Lava\Api\Exceptions\Payoff;

use Lava\Api\Exceptions\BaseException;

class PayoffException extends BaseException
{

}