<?php

namespace Lava\Api\Constants;

class ShopUrlConstants
{

    public const GET_BALANCE = '/business/shop/get-balance';

}