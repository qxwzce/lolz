<?php

namespace Lava\Api\Constants;

class RefundUrlConstants
{

    public const CREATE_REFUND = '/business/invoice/refund';
    public const GET_STATUS_REFUND = '/business/invoice/get-refund-status';

}