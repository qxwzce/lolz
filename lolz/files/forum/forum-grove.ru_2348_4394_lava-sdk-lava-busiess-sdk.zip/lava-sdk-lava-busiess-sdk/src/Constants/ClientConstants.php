<?php

namespace Lava\Api\Constants;

class ClientConstants
{

    public const URL = 'https://api.lava.ru';

}