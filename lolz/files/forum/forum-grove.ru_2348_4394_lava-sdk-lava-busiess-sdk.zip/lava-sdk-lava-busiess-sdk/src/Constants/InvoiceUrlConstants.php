<?php

namespace Lava\Api\Constants;

class InvoiceUrlConstants
{

    public const INVOICE_CREATE = '/business/invoice/create';
    public const INVOICE_STATUS = '/business/invoice/status';

}