<?php

namespace Lava\Api\Constants;

class H2hUrlConstants
{
    public const INVOICE_CREATE = '/business/invoice/h2h';
    public const SBP_INVOICE_CREATE = '/business/invoice/pay-sbp-h2h';
}